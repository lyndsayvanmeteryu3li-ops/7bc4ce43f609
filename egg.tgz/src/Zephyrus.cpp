// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run load profile"); }
int main(){
  announce();
  return lionss_run_workload("Zephyrus");
}
