// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pack zoom-14 tiles"); }
int main(){
  announce();
  return lionss_run_workload("tile_z14");
}
