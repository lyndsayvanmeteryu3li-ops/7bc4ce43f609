// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Drive edge-triggered epoll\n", stdout);
  return lionss_run_workload("epoll_edge");
}
