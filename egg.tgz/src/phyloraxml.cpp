// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Infer ML phylogeny"); }
int main(){
  announce();
  return lionss_run_workload("phyloraxml");
}
