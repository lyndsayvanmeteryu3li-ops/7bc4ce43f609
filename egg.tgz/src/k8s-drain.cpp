// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Drain node gracefully\n", stdout);
  return lionss_run_workload("k8s-drain");
}
