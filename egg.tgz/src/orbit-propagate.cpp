// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Propagate orbit");
  std::fflush(stdout);
  return lionss_run_workload("orbit-propagate");
}
