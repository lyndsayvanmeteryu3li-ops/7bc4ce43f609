// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Connect jump links\n", stdout);
  return lionss_run_workload("navlink-jump");
}
