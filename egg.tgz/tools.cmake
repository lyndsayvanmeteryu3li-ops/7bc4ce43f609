# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(verdigris src/verdigris.cpp)
set_property(TARGET verdigris PROPERTY CXX_STANDARD 11)
target_link_libraries(verdigris lionss pthread)

add_executable(VegaSurface src/VegaSurface.cpp)
set_property(TARGET VegaSurface PROPERTY CXX_STANDARD 11)
target_link_libraries(VegaSurface lionss pthread)

add_executable(thread-border src/thread-border.cpp)
set_property(TARGET thread-border PROPERTY CXX_STANDARD 11)
target_link_libraries(thread-border lionss pthread)

add_executable(snp-call src/snp-call.cpp)
set_property(TARGET snp-call PROPERTY CXX_STANDARD 11)
target_link_libraries(snp-call lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

add_executable(tile_z14 src/tile_z14.cpp)
set_property(TARGET tile_z14 PROPERTY CXX_STANDARD 11)
target_link_libraries(tile_z14 lionss pthread)

add_executable(tle-sgp4 src/tle-sgp4.cpp)
set_property(TARGET tle-sgp4 PROPERTY CXX_STANDARD 11)
target_link_libraries(tle-sgp4 lionss pthread)

add_executable(apiBlueprint src/apiBlueprint.cpp)
set_property(TARGET apiBlueprint PROPERTY CXX_STANDARD 11)
target_link_libraries(apiBlueprint lionss pthread)

add_executable(verglas src/verglas.cpp)
set_property(TARGET verglas PROPERTY CXX_STANDARD 11)
target_link_libraries(verglas lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

add_executable(orbit-propagate src/orbit-propagate.cpp)
set_property(TARGET orbit-propagate PROPERTY CXX_STANDARD 11)
target_link_libraries(orbit-propagate lionss pthread)

add_executable(saffronPike src/saffronPike.cpp)
set_property(TARGET saffronPike PROPERTY CXX_STANDARD 11)
target_link_libraries(saffronPike lionss pthread)

add_executable(epoll_edge src/epoll_edge.cpp)
set_property(TARGET epoll_edge PROPERTY CXX_STANDARD 11)
target_link_libraries(epoll_edge lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(OrcBrawlerLOD2 src/OrcBrawlerLOD2.cpp)
set_property(TARGET OrcBrawlerLOD2 PROPERTY CXX_STANDARD 11)
target_link_libraries(OrcBrawlerLOD2 lionss pthread)

add_executable(spill-tempfile src/spill-tempfile.cpp)
set_property(TARGET spill-tempfile PROPERTY CXX_STANDARD 11)
target_link_libraries(spill-tempfile lionss pthread)

add_executable(pacinggain src/pacinggain.cpp)
set_property(TARGET pacinggain PROPERTY CXX_STANDARD 11)
target_link_libraries(pacinggain lionss pthread)

add_executable(phyloraxml src/phyloraxml.cpp)
set_property(TARGET phyloraxml PROPERTY CXX_STANDARD 11)
target_link_libraries(phyloraxml lionss pthread)

add_executable(navlink-jump src/navlink-jump.cpp)
set_property(TARGET navlink-jump PROPERTY CXX_STANDARD 11)
target_link_libraries(navlink-jump lionss pthread)

add_executable(vermilion src/vermilion.cpp)
set_property(TARGET vermilion PROPERTY CXX_STANDARD 11)
target_link_libraries(vermilion lionss pthread)

add_executable(flintlock src/flintlock.cpp)
set_property(TARGET flintlock PROPERTY CXX_STANDARD 11)
target_link_libraries(flintlock lionss pthread)

add_executable(cordite src/cordite.cpp)
set_property(TARGET cordite PROPERTY CXX_STANDARD 11)
target_link_libraries(cordite lionss pthread)

add_executable(zigComptime src/zigComptime.cpp)
set_property(TARGET zigComptime PROPERTY CXX_STANDARD 11)
target_link_libraries(zigComptime lionss pthread)

add_executable(gc_nursery src/gc_nursery.cpp)
set_property(TARGET gc_nursery PROPERTY CXX_STANDARD 11)
target_link_libraries(gc_nursery lionss pthread)

add_executable(k8s-drain src/k8s-drain.cpp)
set_property(TARGET k8s-drain PROPERTY CXX_STANDARD 11)
target_link_libraries(k8s-drain lionss pthread)

add_executable(cassandra_repair src/cassandra_repair.cpp)
set_property(TARGET cassandra_repair PROPERTY CXX_STANDARD 11)
target_link_libraries(cassandra_repair lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(saltmarsh src/saltmarsh.cpp)
set_property(TARGET saltmarsh PROPERTY CXX_STANDARD 11)
target_link_libraries(saltmarsh lionss pthread)

add_executable(FastqcTrim src/FastqcTrim.cpp)
set_property(TARGET FastqcTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(FastqcTrim lionss pthread)

add_executable(Zephyrus src/Zephyrus.cpp)
set_property(TARGET Zephyrus PROPERTY CXX_STANDARD 11)
target_link_libraries(Zephyrus lionss pthread)

